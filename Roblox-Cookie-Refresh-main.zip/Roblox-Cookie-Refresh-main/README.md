# Roblox-Cookie-Refresh

Roblox Cookie Refresher in Node.js, it can be dualhooked and you can host it on a site like onrender.com, replace the webhook in `server.js`.

# Showcase
https://streamable.com/8wxuz8

## Getting Started

1. Go to [onrender.com](https://onrender.com) and search for a web development app that supports Node.js.
2. Click on "Create New Project" and upload the necessary files.
3. Dualhook the app in the `server.js` file.

## Usage

To start the application on onrender.com, use the following command:

```bash
node installer.js
```

## FOLLOW MY FRIEND ON GITHUB! : https://github.com/EvilBytecode?tab=repositories
